@echo off
setlocal

REM Bootstrap script to run NIEMtools plugout with JavaFX modules
REM Usage from BoUML plugout command: scripts\run-plugout.bat <boumlPort>

set BASE=%~dp0..
set TARGET=%BASE%\target
set LIB=%TARGET%\javafx-lib

if not exist "%LIB%" (
  echo JavaFX libs not found at %LIB%.
  echo Run: mvn -DskipTests package
  exit /b 1
)

REM Choose the built jar name (version from pom.xml)
set APPJAR=%TARGET%\niemtools-2.0.jar
if not exist "%APPJAR%" (
  echo Application jar not found: %APPJAR%
  echo Run: mvn -DskipTests package
  exit /b 1
)

REM Include provided dependencies (commons-lang3, opencsv) copied to target
set CLASSPATH="%APPJAR%";"%TARGET%\*"

REM Run with JavaFX on module-path
java --module-path "%LIB%" --add-modules javafx.controls,javafx.graphics,javafx.fxml -cp %CLASSPATH% org.cabral.niemtools.BoumlPlugout %*

endlocal
