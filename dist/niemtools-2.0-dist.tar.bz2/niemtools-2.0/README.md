# niem-tools
This is a [BOUML](http://bouml.fr "BOUML") "plugout" that supports developing [NIEM](http://niemopen.org "NIEM") message specifications in UML.

[Jim Cabral](mailto:jim@cabral.org) developed this UML-based tool for developing and managing NIEM architectures.  
Portions of this work were supported by [MTG Management Consultants LLC](http://mtgmc.com "MTG") and [InfoTrack US](https://infotrack.com "InfoTrack").

The advantages relative to other tools include:

<b>Standards-Based</b> – Conforms to UML 2.0 and NIEM Naming and Design Rules (NDR).

<b>Free</b> – An open source “plugout” module for BOUML, a free UML modeling program

<b>Simple to Use</b> – Supports round-trip NIEM mapping using a simple spreadsheet.

<b>Complete</b> – Captures UML process and object models and automatically generates HTML documentation, NIEM XML mappings, “want lists”, Common Model Format (CMF) models, XSD and JSON schemas, code lists, and Web Service Definition Language (WSDL) and OpenAPI service definitions.

<b>Future-Proof</b> – Can import and migrate models to future versions of NIEM when released

To get started, see the [HOWTO](HOWTO.md).