
/**
 *   Internal class used to know how what code is produced for a stereotype in each language
 */
final class UmlStereotype {
  public String uml;
  public String cpp;
  public String java;
  public String php;
  public String python;
  public String idl;
};
