
/**
 *  this class manages messages in a collaboration diagram,
 *  you can modify it
 */
class UmlCollaborationMessage extends UmlBaseCollaborationMessage {
}
