
abstract class UmlBaseActivityControlNode extends UmlActivityNode {
  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  protected  UmlBaseActivityControlNode(long id, String s) {
    super(id, s);
  }

}
