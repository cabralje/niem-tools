
interface UmlStateItem {
}
