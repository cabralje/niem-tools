
/**
 *  this class manages class instance reference,
 *  you can modify it
 */
class UmlClassInstanceReference extends UmlBaseClassInstanceReference {
}
