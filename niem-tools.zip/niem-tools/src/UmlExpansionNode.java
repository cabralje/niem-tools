
class UmlExpansionNode extends UmlBaseExpansionNode {
  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  public  UmlExpansionNode(long id, String s) {
    super(id, s);
  }

}
