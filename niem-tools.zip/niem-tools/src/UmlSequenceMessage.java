
/**
 *  this class manages messages in a sequence diagram,
 *  you can modify it
 */
class UmlSequenceMessage extends UmlBaseSequenceMessage {
}
