
/**
 *  this class manages messages indenpendently of the diagram,
 *  you can modify it
 */
class UmlMessage extends UmlBaseMessage {
}
