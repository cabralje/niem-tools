
class UmlChoicePseudoState extends UmlBaseChoicePseudoState {
  /**
   * returns a string indicating the king of the element
   */
  public String sKind() {
    return "choice pseudo state";
  }

  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  public  UmlChoicePseudoState(long id) {
    super(id, "");
  }

}
