
/**
 *  This class manages 'formal parameters' of a template class. For instance 'T' in 
 * 
 * 	template class Cl<class T> ...
 * 
 *  You can modify it as you want (except the constructor)
 */
class UmlFormalParameter extends UmlBaseFormalParameter {
  public UmlFormalParameter(){
  }

};
