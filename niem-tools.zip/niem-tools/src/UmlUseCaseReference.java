
/**
 *  this class manages use case references, you can modify it
 */
class UmlUseCaseReference extends UmlBaseUseCaseReference {
}
