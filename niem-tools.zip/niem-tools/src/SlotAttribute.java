
class SlotAttribute {
  public UmlAttribute attribute;

  public String value;

  public  SlotAttribute(UmlAttribute a, String v) {
    attribute = a;
    value = v;
  }

}
