
/**
 *  this class manages association between use case and actor,
 *  you can modify it
 */
class UmlUseCaseAssociation extends UmlBaseUseCaseAssociation {
}
