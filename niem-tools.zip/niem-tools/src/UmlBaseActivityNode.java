
abstract class UmlBaseActivityNode extends UmlItem {
  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  protected  UmlBaseActivityNode(long id, String s) {
    super(id, s);
  }

}
