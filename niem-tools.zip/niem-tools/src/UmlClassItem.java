
/**
 *  This class globaly manages class's children including UmlClassExtraMember
 * 
 *  You can modify it as you want (except the constructor)
 */
abstract class UmlClassItem extends UmlBaseClassItem {
  public UmlClassItem(long id, String n){ super(id, n); }

};
