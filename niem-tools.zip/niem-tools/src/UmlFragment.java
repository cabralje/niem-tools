
/**
 *  this class manages fragments, you can modify it
 */
class UmlFragment extends UmlBaseFragment {
}
