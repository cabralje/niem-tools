
/**
 *  this class manages collaboration diagram definition,
 *  you can modify it
 */
class UmlCollaborationDiagramDefinition extends UmlBaseCollaborationDiagramDefinition {
}
