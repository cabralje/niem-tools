
/**
 *   Represent an operation's parameter
 */
final class UmlParameter extends UmlBaseParameter {
};
