
/**
 *  this class manages fragments compartments,
 *  a fragment without separator contains one compartment you can modify it
 */
class UmlFragmentCompartment extends UmlBaseFragmentCompartment {
}
