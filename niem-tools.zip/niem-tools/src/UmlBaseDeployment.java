
/**
 *   Manage the deployments
 */
abstract class UmlBaseDeployment extends UmlItem {
  protected UmlBaseDeployment(long id, String n) { super(id, n); }

};
