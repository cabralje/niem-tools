
interface UmlActivityItem {
}
