
abstract class UmlBaseView extends UmlItem {
  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  protected  UmlBaseView(long id, String s) {
    super(id, s);
  }

}
