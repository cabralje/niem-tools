
/**
 *  this class manages use case diagram definition,
 *  you can modify it
 */
class UmlUseCaseDiagramDefinition extends UmlBaseUseCaseDiagramDefinition {
}
