
/**
 *  this class manages subjects, you can modify it
 */
class UmlSubject extends UmlBaseSubject {
}
