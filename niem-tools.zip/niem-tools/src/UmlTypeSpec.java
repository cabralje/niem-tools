
/**
 *  this class memorize a type specification, which may be
 * 
 *  - a class reference
 * 
 *  - an explicit type
 */
class UmlTypeSpec extends UmlBaseTypeSpec {
};
