
/**
 *  this class manages sequence diagram definition,
 *  you can modify it
 */
class UmlSequenceDiagramDefinition extends UmlBaseSequenceDiagramDefinition {
}
