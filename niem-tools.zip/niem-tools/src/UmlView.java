
abstract class UmlView extends UmlBaseView {
  /**
   *   the constructor, do not call it yourself !!!!!!!!!!
   */
  protected  UmlView(long id, String s) {
    super(id, s);
  }

}
